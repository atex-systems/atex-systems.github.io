# Crackit

pdf.js is used to parse pdf in extension git://github.com/mozilla/pdf.js.git
